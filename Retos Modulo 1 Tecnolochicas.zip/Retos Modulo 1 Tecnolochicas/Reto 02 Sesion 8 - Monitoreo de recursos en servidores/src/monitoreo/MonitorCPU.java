package monitoreo;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class MonitorCPU {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Set<Integer> registros = new HashSet<>();

        try {
            System.out.println("Ingrese consumos de CPU (porcentaje). Escriba -1 para terminar:");
            while (true) {
                System.out.print("CPU%: ");
                String entrada = scanner.nextLine();

                if (entrada.equals("-1")) break;

                try {
                    int valor = Integer.parseInt(entrada);

                    if (valor < 0 || valor > 100) {
                        System.out.println("❌ Valor fuera de rango (0-100).");
                        continue;
                    }

                    if (!registros.add(valor)) {
                        System.out.println("⚠️ Valor duplicado, no se registrará.");
                        continue;
                    }

                    if (valor > 95) {
                        throw new ConsumoCriticoException("🔥 Consumo crítico detectado: " + valor + "%");
                    }

                    System.out.println("✅ Registro aceptado.");

                } catch (NumberFormatException e) {
                    System.out.println("❌ Entrada inválida. Debe ser numérica.");
                } catch (ConsumoCriticoException e) {
                    System.out.println("🚨 " + e.getMessage());
                }
            }
        } finally {
            scanner.close();
            System.out.println("📊 Registro de monitoreo finalizado.");
        }
    }
}
