import java.util.Optional;

public class Factura {
    // 🔐 Atributos privados
    private double monto;
    private String descripcion;
    private Optional<String> rfc;

    // 🛠️ Constructor
    public Factura(double monto, String descripcion, String rfc) {
        this.monto = monto;
        this.descripcion = descripcion;
        // Si RFC es null, usamos Optional.empty()
        this.rfc = (rfc == null) ? Optional.empty() : Optional.of(rfc);
    }

    // 🛠️ Método público para obtener el resumen
    public String getResumen() {
        String resumen = "📄 Factura generada:\n" +
                "Descripción: " + descripcion + "\n" +
                "Monto: $" + monto + "\n" +
                "RFC: " + rfc.orElse("[No proporcionado]");
        return resumen;
    }

    // Getters opcionales si necesitas acceder individualmente
    public double getMonto() {
        return monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Optional<String> getRfc() {
        return rfc;
    }
}
