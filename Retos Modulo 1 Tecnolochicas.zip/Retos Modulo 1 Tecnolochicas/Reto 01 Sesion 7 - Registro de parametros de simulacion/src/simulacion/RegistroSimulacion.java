package simulacion;

import java.io.IOException;
import java.nio.file.*;

public class RegistroSimulacion {

    public static void main(String[] args) {
        Path ruta = Paths.get("config/parametros.txt");
        guardarParametros(ruta);
        if (Files.exists(ruta)) {
            System.out.println("✅ Archivo creado correctamente.");
            leerParametros(ruta);
        } else {
            System.out.println("❌ Error: el archivo no se creó.");
        }
    }

    // Método para guardar parámetros en un archivo
    public static void guardarParametros(Path ruta) {
        try {
            // Crear la carpeta si no existe
            if (!Files.exists(ruta.getParent())) {
                Files.createDirectories(ruta.getParent());
            }

            String contenido = """
                    Tiempo de ciclo: 55.8 segundos
                    Velocidad de línea: 1.2 m/s
                    Número de estaciones: 8
                    """;

            Files.write(ruta, contenido.getBytes());
        } catch (IOException e) {
            System.out.println("❌ Error al escribir el archivo: " + e.getMessage());
        }
    }

    // Método para leer parámetros desde el archivo
    public static void leerParametros(Path ruta) {
        try {
            String contenido = Files.readString(ruta);
            System.out.println("📄 Contenido del archivo:");
            System.out.println(contenido);
        } catch (IOException e) {
            System.out.println("❌ Error al leer el archivo: " + e.getMessage());
        }
    }
}
