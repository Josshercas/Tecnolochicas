package pagos;

public class CajaRegistradora {

    public void realizarPago(MetodoPago metodoPago, String usuario, String clave) {
        if (metodoPago instanceof Autenticable) {
            Autenticable a = (Autenticable) metodoPago;
            if (a.autenticar(usuario, clave)) {
                metodoPago.procesarPago();
            } else {
                System.out.println("❌ Falló la autenticación. Pago cancelado.");
            }
        } else {
            System.out.println("⚠️ Este método de pago no requiere autenticación.");
            metodoPago.procesarPago();
        }
    }
}
