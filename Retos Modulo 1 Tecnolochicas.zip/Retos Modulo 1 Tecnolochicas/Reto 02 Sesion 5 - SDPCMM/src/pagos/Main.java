package pagos;

public class Main {
    public static void main(String[] args) {
        CajaRegistradora caja = new CajaRegistradora();

        MetodoPago efectivo = new PagoEfectivo(100.0);
        MetodoPago tarjeta = new PagoTarjeta(200.0, "1234567890123456");
        MetodoPago transferencia = new PagoTransferencia(300.0, "ABC123456");

        caja.realizarPago(efectivo, "usuarioEfectivo", "clave123");
        caja.realizarPago(tarjeta, "usuarioTarjeta", "clave456");
        caja.realizarPago(transferencia, "usuarioTransferencia", "clave789");
    }
}
