package pagos;

public class PagoEfectivo extends MetodoPago implements Autenticable {

    public PagoEfectivo(double monto) {
        super(monto);
    }

    @Override
    public void procesarPago() {
        System.out.println("💵 Procesando pago en efectivo por $" + monto);
    }

    @Override
    public boolean autenticar(String usuario, String clave) {
        // Lógica de autenticación ficticia
        return "usuarioEfectivo".equals(usuario) && "clave123".equals(clave);
    }
}
