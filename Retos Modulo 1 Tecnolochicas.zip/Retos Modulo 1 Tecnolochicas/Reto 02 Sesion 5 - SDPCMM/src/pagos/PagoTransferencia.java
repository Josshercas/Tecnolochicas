package pagos;

public class PagoTransferencia extends MetodoPago implements Autenticable {

    private String cuentaBancaria;

    public PagoTransferencia(double monto, String cuentaBancaria) {
        super(monto);
        this.cuentaBancaria = cuentaBancaria;
    }

    @Override
    public void procesarPago() {
        System.out.println("🏦 Procesando transferencia bancaria desde cuenta "
                + cuentaBancaria + " por $" + monto);
    }

    @Override
    public boolean autenticar(String usuario, String clave) {
        return "usuarioTransferencia".equals(usuario) && "clave789".equals(clave);
    }
}
