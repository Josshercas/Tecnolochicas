package pagos;

public interface Autenticable {
    boolean autenticar(String usuario, String clave);
}
