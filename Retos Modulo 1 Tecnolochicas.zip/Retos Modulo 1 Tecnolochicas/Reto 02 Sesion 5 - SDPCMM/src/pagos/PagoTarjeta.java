package pagos;

public class PagoTarjeta extends MetodoPago implements Autenticable {

    private String numeroTarjeta;

    public PagoTarjeta(double monto, String numeroTarjeta) {
        super(monto);
        this.numeroTarjeta = numeroTarjeta;
    }

    @Override
    public void procesarPago() {
        System.out.println("💳 Procesando pago con tarjeta terminada en "
                + numeroTarjeta.substring(numeroTarjeta.length() - 4) + " por $" + monto);
    }

    @Override
    public boolean autenticar(String usuario, String clave) {
        return "usuarioTarjeta".equals(usuario) && "clave456".equals(clave);
    }
}
