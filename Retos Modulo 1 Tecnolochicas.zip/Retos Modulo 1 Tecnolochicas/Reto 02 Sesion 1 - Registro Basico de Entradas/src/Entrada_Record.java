public record Entrada_Record(String nombreEvento, double precioEntrada) {
    // Método para mostrar la información de la entrada
    public void mostrarInformacion() {
        System.out.println("Evento: " + nombreEvento + " | Precio: $" + precioEntrada);
    }
}
