public class Principal_Record {
    public static void main(String[] args) {
        // Crear objetos de tipo Entrada_Record
        Entrada_Record entrada1 = new Entrada_Record("Festival de Música", 300.0);
        Entrada_Record entrada2 = new Entrada_Record("Espectáculo de Danza", 200.0);

        // Mostrar información de las entradas
        entrada1.mostrarInformacion();
        entrada2.mostrarInformacion();
    }
}
