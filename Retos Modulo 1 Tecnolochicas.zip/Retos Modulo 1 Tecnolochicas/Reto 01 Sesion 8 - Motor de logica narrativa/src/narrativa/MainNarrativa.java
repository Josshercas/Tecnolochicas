package narrativa;

import narrativa.interfaces.*;
import narrativa.implementaciones.*;

public class MainNarrativa {
    public static void main(String[] args) {
        // Inyección de dependencias usando interfaces
        TransicionHistoria transicion = new TransicionSimple();
        GestorDialogo dialogo = new DialogoTexto();
        LogicaDecision decision = new DecisionBinaria();

        // Simulación de escena
        dialogo.mostrarDialogo("El héroe llega a un cruce en el camino.");
        String eleccion = decision.tomarDecision();

        if (eleccion.equals("sí")) {
            dialogo.mostrarDialogo("Decides ayudar al personaje.");
            transicion.avanzarEscena();
        } else {
            dialogo.mostrarDialogo("Ignoras la situación y sigues tu camino.");
            transicion.avanzarEscena();
        }
    }
}
