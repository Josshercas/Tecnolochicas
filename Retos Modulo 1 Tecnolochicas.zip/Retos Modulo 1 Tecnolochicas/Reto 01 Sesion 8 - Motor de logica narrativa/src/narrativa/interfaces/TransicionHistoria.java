// TransicionHistoria.java
package narrativa.interfaces;

public interface TransicionHistoria {
    void avanzarEscena();
}
