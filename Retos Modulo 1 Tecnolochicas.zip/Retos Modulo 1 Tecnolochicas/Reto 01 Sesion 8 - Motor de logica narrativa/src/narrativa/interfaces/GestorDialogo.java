// GestorDialogo.java
package narrativa.interfaces;

public interface GestorDialogo {
    void mostrarDialogo(String texto);
}
