// LogicaDecision.java
package narrativa.interfaces;

public interface LogicaDecision {
    String tomarDecision();
}
