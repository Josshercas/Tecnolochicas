// TransicionSimple.java
package narrativa.implementaciones;

import narrativa.interfaces.TransicionHistoria;

public class TransicionSimple implements TransicionHistoria {
    @Override
    public void avanzarEscena() {
        System.out.println("➡️ La historia avanza a la siguiente escena.");
    }
}
