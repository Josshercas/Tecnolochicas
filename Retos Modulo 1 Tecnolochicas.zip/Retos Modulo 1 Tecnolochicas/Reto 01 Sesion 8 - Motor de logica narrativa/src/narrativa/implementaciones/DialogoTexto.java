// DialogoTexto.java
package narrativa.implementaciones;

import narrativa.interfaces.GestorDialogo;

public class DialogoTexto implements GestorDialogo {
    @Override
    public void mostrarDialogo(String texto) {
        System.out.println("🎤 Narrador: " + texto);
    }
}
