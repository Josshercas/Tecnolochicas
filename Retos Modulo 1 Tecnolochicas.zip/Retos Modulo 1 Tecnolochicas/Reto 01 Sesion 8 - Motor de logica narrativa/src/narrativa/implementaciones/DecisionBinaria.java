// DecisionBinaria.java
package narrativa.implementaciones;

import narrativa.interfaces.LogicaDecision;

import java.util.Scanner;

public class DecisionBinaria implements LogicaDecision {
    @Override
    public String tomarDecision() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("❓ ¿Quieres ayudar al personaje? (sí/no): ");
        return scanner.nextLine().trim().toLowerCase();
    }
}
