public record DeclaracionImpuestos(String rfcContribuyente, double montoDeclarado) {
}
