import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Declaración de impuestos
            System.out.println("🧾 Ingresar declaración de impuestos:");
            System.out.print("RFC del contribuyente: ");
            String rfcDeclaracion = scanner.nextLine();
            System.out.print("Monto declarado: ");
            double montoDeclarado = Double.parseDouble(scanner.nextLine());

            DeclaracionImpuestos declaracion = new DeclaracionImpuestos(rfcDeclaracion, montoDeclarado);

            // Cuenta fiscal
            System.out.println("\n🏦 Ingresar cuenta fiscal:");
            System.out.print("RFC registrado: ");
            String rfcCuenta = scanner.nextLine();
            System.out.print("Saldo disponible: ");
            double saldoDisponible = Double.parseDouble(scanner.nextLine());

            CuentaFiscal cuenta = new CuentaFiscal(rfcCuenta, saldoDisponible);

            // Mostrar información y validación
            System.out.println("\n📄 Declaración enviada por RFC: " + declaracion.rfcContribuyente() +
                    " por $" + declaracion.montoDeclarado());
            System.out.println("🏦 Cuenta fiscal registrada con RFC: " + cuenta.getRfc() +
                    ", saldo disponible: $" + cuenta.getSaldoDisponible());

            boolean rfcValido = cuenta.validarRFC(declaracion);
            System.out.println(rfcValido ? "✅ ¿RFC válido para esta cuenta?: true"
                    : "❌ ¿RFC válido para esta cuenta?: false");

        } catch (NumberFormatException e) {
            System.out.println("❌ Error: Monto inválido. Usa punto decimal si es necesario (ej. 8700.50).");
        }

        scanner.close();
    }
}


