package temario;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Collections;
import java.util.Comparator;

public class GestorTemario {
    public static void main(String[] args) {

        // Lista segura de temas
        CopyOnWriteArrayList<Tema> temas = new CopyOnWriteArrayList<>();
        temas.add(new Tema("Lectura comprensiva", 2));
        temas.add(new Tema("Matemáticas básicas", 1));
        temas.add(new Tema("Cuidado del medio ambiente", 3));

        // Repositorio compartido con enlaces reales
        ConcurrentHashMap<String, String> recursos = new ConcurrentHashMap<>();
        recursos.put("Lectura comprensiva", "https://cdn.puntajenacional.cl/uploads/guia/4419615198866dd51552c4b2691e22168bbfc44ed72b67e3c698.pdf");
        recursos.put("Matemáticas básicas", "https://matematicassolidarias.org/wp-content/uploads/2021/12/GUIA-DE-ESTUDIO_MATEX-Ba%CC%81sicas-I.pdf");
        recursos.put("Cuidado del medio ambiente", "https://www.gob.mx/cms/uploads/attachment/file/829255/Guia_Medio_Ambiente_2023.pdf");

        // Mostrar temas ordenados alfabéticamente
        System.out.println("📚 Temas ordenados alfabéticamente:");
        Collections.sort(temas);
        for (Tema t : temas) {
            System.out.println("- " + t);
        }

        // Ordenar temas por prioridad ascendente
        System.out.println("\n🔢 Temas ordenados por prioridad:");
        temas.sort(Comparator.comparingInt(Tema::getPrioridad));
        for (Tema t : temas) {
            System.out.println("- " + t);
        }

        // Mostrar recursos asociados a cada tema
        System.out.println("\n🧠 Recursos por tema:");
        for (String tema : recursos.keySet()) {
            System.out.println(tema + " → " + recursos.get(tema));
        }
    }
}
