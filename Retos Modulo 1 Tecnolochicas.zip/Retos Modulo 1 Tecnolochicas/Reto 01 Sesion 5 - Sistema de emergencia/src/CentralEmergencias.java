import java.util.Scanner;

// Clase principal
public class CentralEmergencias {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nombre del operador de la ambulancia: ");
        Ambulancia ambulancia = new Ambulancia(scanner.nextLine());
        ambulancia.iniciarOperacion();

        System.out.print("Nombre del operador de la patrulla: ");
        Patrulla patrulla = new Patrulla(scanner.nextLine());
        patrulla.iniciarOperacion();

        System.out.print("Nombre del operador de la unidad de bomberos: ");
        UnidadBomberos bomberos = new UnidadBomberos(scanner.nextLine());
        bomberos.iniciarOperacion();

        scanner.close();
    }
}