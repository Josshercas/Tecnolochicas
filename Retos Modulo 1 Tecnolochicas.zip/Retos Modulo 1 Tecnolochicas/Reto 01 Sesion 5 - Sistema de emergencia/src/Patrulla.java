// Subclases
class Patrulla extends UnidadEmergencia {
    private SistemaGPS gps = new SistemaGPS();
    private Sirena sirena = new Sirena();
    private Operador operador;

    public Patrulla(String operadorNombre) {
        super("Patrulla");
        this.operador = new Operador(operadorNombre);
    }

    @Override
    void responder() {
        System.out.println("🚓 Patrulla atendiendo situación de seguridad ciudadana.");
    }

    public void iniciarOperacion() {
        activarUnidad();
        gps.localizar();
        sirena.activarSirena();
        operador.reportarse();
        responder();
    }
}