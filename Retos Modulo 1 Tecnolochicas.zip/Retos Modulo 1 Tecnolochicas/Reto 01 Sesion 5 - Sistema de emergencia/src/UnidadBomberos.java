// Subclases
class UnidadBomberos extends UnidadEmergencia {
    private SistemaGPS gps = new SistemaGPS();
    private Sirena sirena = new Sirena();
    private Operador operador;

    public UnidadBomberos(String operadorNombre) {
        super("Unidad de Bomberos");
        this.operador = new Operador(operadorNombre);
    }

    @Override
    void responder() {
        System.out.println("🔥 Unidad de bomberos respondiendo a incendio estructural.");
    }

    public void iniciarOperacion() {
        activarUnidad();
        gps.localizar();
        sirena.activarSirena();
        operador.reportarse();
        responder();
    }
}