// Clases auxiliares
class Sirena {
    public void activarSirena() {
        System.out.println("🔊 Sirena: Activada.");
    }
}