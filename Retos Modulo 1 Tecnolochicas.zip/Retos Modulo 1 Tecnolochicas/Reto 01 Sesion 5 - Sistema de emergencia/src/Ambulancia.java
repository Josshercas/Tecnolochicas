// Subclases
class Ambulancia extends UnidadEmergencia {
    private SistemaGPS gps = new SistemaGPS();
    private Sirena sirena = new Sirena();
    private Operador operador;

    public Ambulancia(String operadorNombre) {
        super("Ambulancia");
        this.operador = new Operador(operadorNombre);
    }

    @Override
    void responder() {
        System.out.println("🩺 Ambulancia en camino al hospital más cercano.");
    }

    public void iniciarOperacion() {
        activarUnidad();
        gps.localizar();
        sirena.activarSirena();
        operador.reportarse();
        responder();
    }
}
