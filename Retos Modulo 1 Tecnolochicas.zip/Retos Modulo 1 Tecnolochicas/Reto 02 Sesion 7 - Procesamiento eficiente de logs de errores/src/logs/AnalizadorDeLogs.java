package logs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AnalizadorDeLogs {

    public static void main(String[] args) {
        Path rutaLog = Paths.get("errores.log"); // Cambia por "no_existe.log" para probar errores

        int totalLineas = 0;
        int errores = 0;
        int advertencias = 0;

        try (BufferedReader reader = Files.newBufferedReader(rutaLog)) {
            String linea;

            while ((linea = reader.readLine()) != null) {
                totalLineas++;

                if (linea.contains("ERROR")) {
                    errores++;
                }
                if (linea.contains("WARNING")) {
                    advertencias++;
                }
            }

            System.out.println("📊 Resumen del log:");
            System.out.println("Total de líneas: " + totalLineas);
            System.out.println("Cantidad de errores: " + errores);
            System.out.println("Cantidad de advertencias: " + advertencias);

            if (totalLineas > 0) {
                double porcentaje = ((errores + advertencias) * 100.0) / totalLineas;
                System.out.printf("Porcentaje de líneas con ERROR o WARNING: %.2f%%\n", porcentaje);
            }

        } catch (IOException e) {
            System.out.println("❌ Ocurrió un error al procesar el archivo.");

            Path rutaError = Paths.get("registro_fallos.txt");

            try (BufferedWriter writer = Files.newBufferedWriter(rutaError)) {
                writer.write("Mensaje de error: " + e.getMessage());
            } catch (IOException ex) {
                System.out.println("❌ Además, no se pudo escribir en el archivo de registro de fallos.");
            }
        }
    }
}
