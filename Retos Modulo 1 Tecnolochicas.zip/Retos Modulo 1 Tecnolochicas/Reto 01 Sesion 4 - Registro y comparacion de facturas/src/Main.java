import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Factura 1
            System.out.println("📋 Ingresa los datos de la primera factura:");
            System.out.print("Folio: ");
            String folio1 = scanner.nextLine();
            System.out.print("Cliente: ");
            String cliente1 = scanner.nextLine();
            System.out.print("Total: ");
            double total1 = Double.parseDouble(scanner.nextLine());

            Factura factura1 = new Factura(folio1, cliente1, total1);

            // Factura 2
            System.out.println("\n📋 Ingresa los datos de la segunda factura:");
            System.out.print("Folio: ");
            String folio2 = scanner.nextLine();
            System.out.print("Cliente: ");
            String cliente2 = scanner.nextLine();
            System.out.print("Total: ");
            double total2 = Double.parseDouble(scanner.nextLine());

            Factura factura2 = new Factura(folio2, cliente2, total2);

            // Mostrar resultados
            System.out.println("\n🧾 Factura 1: " + factura1);
            System.out.println("🧾 Factura 2: " + factura2);
            System.out.println("¿Las facturas son iguales?: " + factura1.equals(factura2));
        } catch (NumberFormatException e) {
            System.out.println("❌ Error: Ingresaste un total no válido. Asegúrate de usar punto decimal (ej: 1234.50).");
        }

        scanner.close();
    }
}
