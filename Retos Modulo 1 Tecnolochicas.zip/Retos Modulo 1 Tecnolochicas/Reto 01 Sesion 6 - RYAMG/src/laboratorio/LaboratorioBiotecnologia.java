package laboratorio;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Scanner;

public class LaboratorioBiotecnologia {
    public static void main(String[] args) {

        // Paso 1: Registrar el orden de llegada de las muestras
        ArrayList<String> muestras = new ArrayList<>();
        muestras.add("Homo sapiens");
        muestras.add("Mus musculus");
        muestras.add("Arabidopsis thaliana");
        muestras.add("Homo sapiens"); // repetida a propósito

        // Paso 2: Filtrar especies únicas usando HashSet
        HashSet<String> especiesUnicas = new HashSet<>(muestras);

        // Paso 3: Asociar ID de muestra con investigador
        HashMap<String, String> muestrasInvestigador = new HashMap<>();
        muestrasInvestigador.put("M-001", "Dra. López");
        muestrasInvestigador.put("M-002", "Dr. Hernández");
        muestrasInvestigador.put("M-003", "Dra. Ramírez");

        // Paso 4: Mostrar resultados
        System.out.println("📋 Lista completa y ordenada de muestras:");
        for (String muestra : muestras) {
            System.out.println("- " + muestra);
        }

        System.out.println("\n🧬 Especies únicas procesadas:");
        for (String especie : especiesUnicas) {
            System.out.println("- " + especie);
        }

        System.out.println("\n🧑‍🔬 Relación de ID de muestra → Investigador:");
        for (String id : muestrasInvestigador.keySet()) {
            System.out.println(id + " → " + muestrasInvestigador.get(id));
        }

        // Paso adicional: Buscar por ID
        Scanner scanner = new Scanner(System.in);
        System.out.print("\n🔍 Ingresa un ID de muestra para buscar al investigador (ej. M-002): ");
        String idBuscado = scanner.nextLine();

        if (muestrasInvestigador.containsKey(idBuscado)) {
            System.out.println("🔎 Investigador responsable: " + muestrasInvestigador.get(idBuscado));
        } else {
            System.out.println("⚠️ ID no encontrado.");
        }

        scanner.close();
    }
}
