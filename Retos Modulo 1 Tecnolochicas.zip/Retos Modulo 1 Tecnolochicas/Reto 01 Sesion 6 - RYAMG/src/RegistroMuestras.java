
import java.util.*;

public class RegistroMuestras {
    public static void main(String[] args) {

        // Paso 1: Registrar el orden de llegada de las muestras
        ArrayList<String> muestras = new ArrayList<>();
        muestras.add("Homo sapiens");
        muestras.add("Mus musculus");
        muestras.add("Arabidopsis thaliana");
        muestras.add("Homo sapiens"); // muestra repetida

        // Paso 2: Identificar especies únicas
        HashSet<String> especiesUnicas = new HashSet<>(muestras);

        // Paso 3: Asociar ID de muestra con investigador
        HashMap<String, String> idInvestigador = new HashMap<>();
        idInvestigador.put("M-001", "Dra. López");
        idInvestigador.put("M-002", "Dr. Hernández");
        idInvestigador.put("M-003", "Dra. Gómez");

        // Paso 4: Mostrar resultados
        System.out.println("📥 Orden de llegada de muestras:");
        for (String especie : muestras) {
            System.out.println("- " + especie);
        }

        System.out.println("\n🧬 Especies únicas procesadas:");
        for (String especie : especiesUnicas) {
            System.out.println("- " + especie);
        }

        System.out.println("\n🧑‍🔬 Relación ID de muestra → Investigador:");
        for (String id : idInvestigador.keySet()) {
            System.out.println(id + " → " + idInvestigador.get(id));
        }

        // Búsqueda por ID
        String buscarID = "M-002";
        System.out.println("\n🔍 Búsqueda de muestra ID " + buscarID + ":");
        if (idInvestigador.containsKey(buscarID)) {
            System.out.println("Responsable: " + idInvestigador.get(buscarID));
        } else {
            System.out.println("ID no encontrado.");
        }
    }
}
